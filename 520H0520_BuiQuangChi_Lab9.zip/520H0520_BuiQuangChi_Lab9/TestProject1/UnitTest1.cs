using StudentServiceLib;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private Student stu;

        [TestInitialize]
        public void init()
        {
            stu = new Student();
        }

        [TestMethod]
        public void exceptionShouldThrow()
        {
            double scr = 7;
            Boolean result = true;
            try
            {
            stu.Score = scr;
            }
            catch(SystemException)
            {
                result = false;
            }
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void exceptionScoreEqual_10()
        {
            double scr = 10;
            Boolean result = true;
            try
            {
                stu.Score = scr;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void exceptionScoreSmallerThan_0()
        {
            double scr = -10;
            Boolean result = true;
            try
            {
                stu.Score = scr;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void exceptionScoreLargerThan_10()
        {
            double scr = 12;
            Boolean result = true;
            try
            {
                stu.Score = scr;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsFalse(result);
        }
    }
}