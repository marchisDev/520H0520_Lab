﻿namespace TestProject1
{
    internal class Score
    {
    }
}